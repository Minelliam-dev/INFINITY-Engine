#version 330

out vec4 outputColor;

in vec2 texCoord;
in vec3 fragWorldPos;

uniform sampler2D texture0;

#define MAX_LIGHTS 64

uniform vec3 lightPositions[MAX_LIGHTS];
uniform vec3 lightColors[MAX_LIGHTS];
uniform float lightStrengths[MAX_LIGHTS];
uniform int lightCount;

float ClampToonBrightness(float Bright) 
{
    float Low = 0.2;
    float Normal = 0.6;
    float High = 0.8;
    
    if (Bright > Low && Bright < Normal) Bright = Low;
    else if (Bright > Normal && Bright < High) Bright = Normal;
    else if (Bright > High) Bright = High;
    else if (Bright < Low) Bright = 0; 
    
    return Bright;
}

void main()
{
    vec4 texColor = texture(texture0, texCoord);

    // Minimum brightness so areas without lights aren't completely black.
    vec4 brightness;

    for (int i = 0; i < lightCount; i++)
    {
        vec3 difference = lightPositions[i] - fragWorldPos;

        // Squared distance. Avoids needing sqrt().
        float distanceSquared = dot(difference, difference);

        float light =
            lightStrengths[i] / (distanceSquared + 1.0);

        brightness.rbg += (lightColors[i] * ClampToonBrightness(light));
    }

    brightness = clamp(brightness, 0.0, 1.0);

    outputColor = texColor + brightness;
}